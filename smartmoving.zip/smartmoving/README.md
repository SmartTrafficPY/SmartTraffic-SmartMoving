<p align="center">
    <a href="http://smarttraffic.com.py"><img src="https://github.com/SmartTrafficPY/smartparking/blob/master/header-smartTraffic.png"        title="SmartTraffic" alt="SmartTraffic"></a>
</p>

# SmartTraffic-SmartMoving
Desarrollo parte cliente del sistema `SmartMoving`

Repositorio correspondiente al desarrollo de la parte cliente de la herramienta `SmartMoving`, uno de los casos de estudio dentro del marco proyecto `SmartTraffic`.

## REQUIREMENTS

Install `Android studio`. A guide for installing android studio 
can be found here: [Installation](https://developer.android.com/studio/install)

## Guide

Clone this project and open it in `Android studio`. To run the application on a cell phone 
you need to follow this guide:(https://developer.android.com/studio/run/device)

## Back-end
The guide to install the back-end for this repo 
can be found here: [smartcity repository](https://github.com/SmartTrafficPY/smartcity-asuncion)

